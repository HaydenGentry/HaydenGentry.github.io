from flask import render_template, request, redirect, url_for, session, jsonify, flash
from app import db #app
from app.models import User, GameStats
from app.sudoku_generator import SudokuGenerator
import re

DIFFICULTY_EMPTY_CELLS = {
    'easy': 36,
    'medium': 40, #48
    'hard': 44,
    'expert': 48,
    'master': 52,
    'extreme': 56
}

# Validate password meets requirements
def validate_password(password):
    if len(password) < 8:
        return False, "Password must be at least 8 characters long"
    if not re.search(r'[A-Z]', password):
        return False, "Password must contain at least one uppercase letter"
    if not re.search(r'[a-z]', password):
        return False, "Password must contain at least one lowercase letter"
    if not re.search(r'[!@#$%^&*(),.{}|<>]', password):
        return False, "Password must contain at least one special character"
    return True, ""

def init_routes(app):    #
    @app.route('/')
    def home():
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return render_template('index.html')

    @app.route('/register', methods=['GET', 'POST'])
    def register():
        if request.method == 'POST':
            username = request.form.get('username', '').strip()
            email = request.form.get('email', '').strip()
            password = request.form.get('password', '')
            confirm_password = request.form.get('confirm_password', '')
            
            # Validation
            if not username or not email or not password:
                flash('All fields are required', 'error')
                return render_template('register.html')
            
            if password != confirm_password:
                flash('Passwords do not match', 'error')
                return render_template('register.html')
            
            valid, msg = validate_password(password)
            if not valid:
                flash(msg, 'error')
                return render_template('register.html')
            
            # Check if username exists
            if User.query.filter_by(username=username).first():
                flash('Username already exists', 'error')
                return render_template('register.html')
            
            # Check if email exists
            if User.query.filter_by(email=email).first():
                flash('Email already registered', 'error')
                return render_template('register.html')
            
            # Create new user
            user = User(username=username, email=email)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            
            session['user_id'] = user.id
            session['username'] = user.username
            flash('Registration successful!', 'success')
            return redirect(url_for('home'))
        
        return render_template('register.html')
    
    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            username = request.form.get('username', '').strip()
            password = request.form.get('password', '')
            
            if not username or not password:
                flash('Username and password are required', 'error')
                return render_template('login.html')
            
            user = User.query.filter_by(username=username).first()
            
            if not user or not user.check_password(password):
                flash('Invalid username or password', 'error')
                return render_template('login.html')
            
            session['user_id'] = user.id
            session['username'] = user.username
            flash('Login successful!', 'success')
            return redirect(url_for('home'))
        
        return render_template('login.html')
    
    @app.route('/logout')
    def logout():
        session.clear()
        flash('You have been logged out', 'success')
        return redirect(url_for('login'))
    
    @app.route('/profile')
    def profile():
        if 'user_id' not in session:
            return redirect(url_for('login'))
        
        user_id = session['user_id']
        username = session['username']
        
        # Get stats for each difficulty
        stats_by_difficulty = {}
        for difficulty in ['easy', 'medium', 'hard', 'expert', 'master', 'extreme']:
            stats = GameStats.get_user_stats(user_id, difficulty)
            stats_by_difficulty[difficulty] = stats
        
        return render_template('profile.html', 
                             username=username,
                             stats_by_difficulty=stats_by_difficulty)
    
    @app.route('/puzzle/<difficulty>')
    def puzzle(difficulty):
        # Validate difficulty level
        if difficulty.lower() not in DIFFICULTY_EMPTY_CELLS:
            return "Invalid difficulty level", 404
        
        try:
            # Generate puzzle based on difficulty
            generator = SudokuGenerator()
            num_empty = DIFFICULTY_EMPTY_CELLS[difficulty.lower()]

            # print(f"Generating puzzle with {num_empty} empty cells...")
            puzzle_grid, solution_grid = generator.generate_puzzle(num_empty)

            # print(f"Puzzle generated successfully")
            # print(f"Puzzle grid type: {type(puzzle_grid)}, length: {len(puzzle_grid)}")
            # print(f"Solution grid type: {type(solution_grid)}, length: {len(solution_grid)}")

            puzzle_list = [list(row) for row in puzzle_grid]
            solution_list = [list(row) for row in solution_grid]

            # Store solution in session for verification later
            session['solution'] = solution_list
            session['difficulty'] = difficulty.lower()
            session['puzzle_start_time'] = None

            return render_template('puzzle.html', 
                                difficulty=difficulty.title(),
                                puzzle=puzzle_list,
                                solution = solution_list)
        
        except Exception as e:
            print(f"Error generating puzzle: {str(e)}")
            import traceback
            traceback.print_exc()
            return f"Error generating puzzle: {str(e)}", 500
        
    @app.route('/save_game_stats', methods=['POST'])
    def save_game_stats():
        if 'user_id' not in session:
            return jsonify({'success': False, 'message': 'Not logged in'})
        
        data = request.json
        user_id = session['user_id']
        difficulty = session.get('difficulty', 'medium')
        completed = data.get('completed', False)
        time_seconds = data.get('time_seconds', 0)
        
        # Save game stats
        game_stat = GameStats(
            user_id=user_id,
            difficulty=difficulty,
            completed=completed,
            time_seconds=time_seconds if completed else None
        )
        db.session.add(game_stat)
        db.session.commit()
        
        return jsonify({'success': True})

from flask import current_app #
init_routes(current_app._get_current_object() if hasattr(current_app, '_get_current_object') 
            else current_app) #
