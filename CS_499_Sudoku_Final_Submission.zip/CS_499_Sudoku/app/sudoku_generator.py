import random
import copy

class SudokuGenerator:
    def __init__(self):
        self.grid = [[0 for _ in range(9)] for _ in range(9)]
        
    # Fill the grid to create a valid complete sudoku solution
    def is_valid(self, grid, row, col, num):
        # Check row
        if num in grid[row]:
            return False
        
        # Check column
        if num in [grid[i][col] for i in range(9)]:
            return False
        
        # Check 3x3 box
        box_row, box_col = 3 * (row // 3), 3 * (col // 3)
        for i in range(box_row, box_row + 3):
            for j in range(box_col, box_col + 3):
                if grid[i][j] == num:
                    return False
        
        return True
    # Fill the grid to create a valid complete sudoku solution
    def fill_grid(self, grid):
        for row in range(9):
            for col in range(9):
                if grid[row][col] == 0:
                    # Randomize numbers to create different puzzles
                    numbers = list(range(1, 10))
                    random.shuffle(numbers)
                    
                    for num in numbers:
                        if self.is_valid(grid, row, col, num):
                            grid[row][col] = num
                            
                            if self.fill_grid(grid):
                                return True
                            
                            grid[row][col] = 0
                    
                    return False
        return True
    # Count the number of solutions (stops at limit for efficiency)
    def count_solutions(self, grid, limit=2):
        count = [0]
        
        def solve(g):
            if count[0] >= limit:
                return
            
            for row in range(9):
                for col in range(9):
                    if g[row][col] == 0:
                        for num in range(1, 10):
                            if self.is_valid(g, row, col, num):
                                g[row][col] = num
                                solve(g)
                                g[row][col] = 0
                        return
            
            count[0] += 1
        
        grid_copy = copy.deepcopy(grid)
        solve(grid_copy)
        return count[0]
    # Remove numbers from completed grid ensuring unique solution
    def remove_numbers(self, grid, num_empty):
        positions = [(r, c) for r in range(9) for c in range(9)]
        random.shuffle(positions)
        
        removed = 0
        attempts = 0
        max_attempts = num_empty * 3
        
        while removed < num_empty and attempts < max_attempts:
            if not positions:
                break
            
            row, col = positions.pop()
            attempts += 1
            
            if grid[row][col] == 0:
                continue
            
            backup = grid[row][col]
            grid[row][col] = 0
            
            grid_copy = copy.deepcopy(grid)
            if self.count_solutions(grid_copy, limit=2) == 1:
                removed += 1
            else:
                grid[row][col] = backup
        
        return removed
    #Generate a sudoku puzzle with specified number of empty cells 
    def generate_puzzle(self, num_empty=40):
        if num_empty < 0 or num_empty > 81:
            raise ValueError("num_empty must be between 0 and 81")
        
        self.grid = [[0 for _ in range(9)] for _ in range(9)]
        self.fill_grid(self.grid)
        solution = copy.deepcopy(self.grid)
        
        actual_removed = self.remove_numbers(self.grid, num_empty)
        
        return self.grid, solution

