from flask import Flask ##
from flask_sqlalchemy import SQLAlchemy #
import sys #
import os #

db = SQLAlchemy() #

def create_app(): #
    app = Flask(__name__) #
    sys.path.insert(0, os.path.dirname(os.path.dirname(__file__))) #
    app.config.from_object('config.Config') #

    db.init_app(app) #

    with app.app_context(): #
        from app import routes #
        db.create_all() #

    return app #

