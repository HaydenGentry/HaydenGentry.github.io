function goHome() {
    if (confirm('Are you sure you want to leave? Your progress will be lost.')) {
        window.location.href = '/';
    }
}

function clearGrid() {
    const inputs = document.querySelectorAll('.cell-input:not(.given)');
    inputs.forEach(input => {
        input.value = '';
        input.classList.remove('incorrect');
    });
    
    // Reset mistakes
    mistakes = 0;
    updateMistakeCounter();
    
    // Clear message
    const messageEl = document.getElementById('message');
    messageEl.textContent = '';
    messageEl.className = '';
}

function updateMistakeCounter() {
    const mistakeCount = document.getElementById('mistake-count');
    mistakeCount.textContent = mistakes;
    
    if (mistakes >= MAX_MISTAKES) {
        mistakeCount.style.color = '#d32f2f';
    }
}

function checkCell(input) {
    const value = parseInt(input.value);
    const correctValue = parseInt(input.dataset.solution);
    
    if (!value) {
        // Empty cell - remove any error styling
        input.classList.remove('incorrect');
        return;
    }
    
    if (value !== correctValue) {
        // Wrong answer
        if (!input.classList.contains('incorrect')) {
            // First time marking this cell as incorrect
            input.classList.add('incorrect');
            mistakes++;
            updateMistakeCounter();
            
            if (mistakes >= MAX_MISTAKES) {
                gameOver(false);
            }
        }
    } else {
        // Correct answer
        input.classList.remove('incorrect');
        input.classList.add('correct');
        
        // Check if puzzle is complete
        checkCompletion();
    }
}

function checkCompletion() {
    const editableCells = document.querySelectorAll('.cell-input:not(.given)');
    let allFilled = true;
    let allCorrect = true;
    
    editableCells.forEach(input => {
        if (!input.value) {
            allFilled = false;
        } else if (parseInt(input.value) !== parseInt(input.dataset.solution)) {
            allCorrect = false;
        }
    });
    
    if (allFilled && allCorrect && mistakes < MAX_MISTAKES) {
        gameOver(true);
    }
}

function gameOver(won) {
    const messageEl = document.getElementById('message');
    
    // Disable all inputs
    const editableCells = document.querySelectorAll('.cell-input:not(.given)');
    editableCells.forEach(input => {
        input.disabled = true;
    });
    
    if (won) {
        messageEl.textContent = '🎉 Congratulations! You solved the puzzle!';
        messageEl.className = 'success';
    } else {
        messageEl.textContent = '❌ Game Over! You made 3 mistakes. Try again?';
        messageEl.className = 'error';
        
        // Show solution
        setTimeout(() => {
            if (confirm('Would you like to see the solution?')) {
                revealSolution();
            }
        }, 1000);
    }
}

function revealSolution() {
    const editableCells = document.querySelectorAll('.cell-input:not(.given)');
    editableCells.forEach(input => {
        input.value = input.dataset.solution;
        input.classList.remove('incorrect');
        input.classList.add('revealed');
    });
}

// Add event listeners to all editable cells
document.addEventListener('DOMContentLoaded', function() {
    const editableCells = document.querySelectorAll('.cell-input:not(.given)');
    
    editableCells.forEach(input => {
        // Check on input change
        input.addEventListener('input', function() {
            // Only allow numbers 1-9
            if (this.value && (this.value < 1 || this.value > 9)) {
                this.value = '';
                return;
            }
            
            checkCell(this);
        });
        
        // Prevent invalid characters
        input.addEventListener('keypress', function(e) {
            const char = String.fromCharCode(e.which);
            if (!/[1-9]/.test(char)) {
                e.preventDefault();
            }
        });
    });
});

