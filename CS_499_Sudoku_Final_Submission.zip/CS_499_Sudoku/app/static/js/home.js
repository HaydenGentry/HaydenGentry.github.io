function openDifficultyModal() {
    document.getElementById('difficultyModal').style.display = 'block';
}

function closeDifficultyModal() {
    document.getElementById('difficultyModal').style.display = 'none';
}

function selectDifficulty(difficulty) {
    window.location.href = '/puzzle/' + difficulty;
}

// Close modal when clicking outside of it
window.onclick = function(event) {
    const modal = document.getElementById('difficultyModal');
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}