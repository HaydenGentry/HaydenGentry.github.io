from flask import render_template, request, jsonify
from app import app

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/puzzle/<difficulty>')
def puzzle(difficulty):
    # Validate difficulty level
    valid_difficulties = ['easy', 'medium', 'hard', 'expert', 'master', 'extreme']
    if difficulty.lower() not in valid_difficulties:
        return "Invalid difficulty level", 404
    
    return render_template('puzzle.html', difficulty=difficulty.title())

if __name__ == '__main__':
    app.run(debug=True)